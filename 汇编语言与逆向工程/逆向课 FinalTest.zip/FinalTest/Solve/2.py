target = [  91, 96, 105, 100, 78, 125, 70, 64, 91, 106, 99, 94, 1]
mid = [  1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
def dec(v1):
    for i in range(len(v1)):
        v1[i] = ( (v1[i] & 0b111) << 3)| ((v1[i] & 0b111000) >> 3) | v1[i] & 0b11000000
    return v1
for i in range(13):
    target[i] ^= mid[i]

print ''.join([chr(i) for i in dec(target)])