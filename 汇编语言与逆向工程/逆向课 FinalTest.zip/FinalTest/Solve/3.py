from Crypto.Cipher import DES
from Crypto import Random

key = b'REVERSE!'
cipher = DES.new(key, DES.MODE_ECB)
plaintext = b'f\xD3\xD5\xF4\x1A\xBF\x81('
msg = cipher.decrypt(plaintext)

print(msg)