a = b'qvldxt'
k = []
v = []
v8 = 5
v7 = 7
for i in a:
    k.append(ord(i)-97)
for i in k:
    v.append(chr( (((i-7)*21) % 26) + 97))
for i in v:
    print chr((v7 + v8 * (ord(i) - 97)) % 26 + 97)
