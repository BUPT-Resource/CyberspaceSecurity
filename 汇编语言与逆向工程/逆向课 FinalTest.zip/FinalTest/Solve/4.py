# a = '\xD5#\xA5"u\xD8\xB7\x80'

from Crypto.Cipher import ARC4
# 加密 

key = b'YQTMGT'
for i in key:
    print(chr(i+2))
cipher = ARC4.new(key) #返回一个ARC4Cipher object
msg = cipher.encrypt(b'\xD5#\xA5"u\xD8\xB7\x80')
print('ARC4加密密文：',msg)