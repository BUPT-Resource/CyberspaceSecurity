a   = '\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A'[::-1]
mid = '\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A'
v = '\TTWL_FXP:'
out = ""
out2= ""
for i in range(10):
    out += chr(ord(v[i]) ^ ord(mid[i]))
for i in range(10):
    out2 += chr(ord(out[i]) ^ ord(a[i]))
print out2