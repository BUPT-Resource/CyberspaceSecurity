from Crypto.Cipher import ARC4
#加密 

key = b'Very long and confidential key'
cipher = ARC4.new(key) #返回一个ARC4Cipher object
msg = cipher.encrypt(b'Open the pod bay doors, HAL')
print('ARC4加密密文：',msg)