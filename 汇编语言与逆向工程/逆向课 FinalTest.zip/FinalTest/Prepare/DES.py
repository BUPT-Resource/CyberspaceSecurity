from Crypto.Cipher import DES
from Crypto import Random

key = b'DE3_En1C'
cipher = DES.new(key, DES.MODE_ECB)
plaintext = b'\xef\x34\xd4\xa3\xc6\x84\xe4\x23'
msg = cipher.decrypt(plaintext)

print(msg)